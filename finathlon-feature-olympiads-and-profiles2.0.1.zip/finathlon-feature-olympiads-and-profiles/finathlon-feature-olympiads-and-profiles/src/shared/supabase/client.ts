import { createClient } from '@supabase/supabase-js'

import {
  captureRecoveryFromUrl,
  markPasswordRecovery,
} from '@/shared/auth/recovery'

import type { Database } from './types'

const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_KEY

if (!url || !key) {
  throw new Error(
    'Missing Supabase env vars. Check VITE_SUPABASE_URL and VITE_SUPABASE_KEY in .env.local',
  )
}

export const supabase = createClient<Database>(url, key, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
})

captureRecoveryFromUrl()

supabase.auth.onAuthStateChange((event) => {
  if (event === 'PASSWORD_RECOVERY') markPasswordRecovery()
})
