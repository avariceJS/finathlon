export { PartnersPage } from './PartnersPage'
