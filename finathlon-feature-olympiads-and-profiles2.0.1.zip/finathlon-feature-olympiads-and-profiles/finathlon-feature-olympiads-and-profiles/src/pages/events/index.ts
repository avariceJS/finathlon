export { EventsPage } from './EventsPage'
